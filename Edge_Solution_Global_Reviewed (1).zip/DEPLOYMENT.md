# Deployment checklist

Deploy this entire folder as the Vercel project root. Do not upload only `index.html`; the blog, services and policy routes depend on their folders being included.

After deployment, verify `/`, `/services/`, `/blog/`, every blog article, `/privacy-policy/`, `/robots.txt` and `/sitemap.xml`. Add the sitemap in Google Search Console, request indexing for the homepage and services page, and monitor Coverage and Core Web Vitals. Rankings cannot be guaranteed; they depend on competition, authority, content quality and ongoing work.
